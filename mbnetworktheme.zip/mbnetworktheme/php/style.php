<?php

require_once('view/theme/redbasic/php/style.php');

echo @file_get_contents('view/theme/mbnetwork/css/style.css');
