<?php

/**
 *   * Name: MBNetwork
 *   * Description: Hubzilla standard theme
 *   * Version: 1,2
 *   * MinVersion: 2.3.1
 *   * MaxVersion: 6.0
 *   * Author: Tan Siret AKINCI
 *   * Maintainer: Mike Macgirvin
 *   * Maintainer: Mario Vavti
 */

function redbasic_init(&$a) {

}
