<?php
	
	if (! $nav_bg)
		$nav_bg = "#fff";
	if (! $nav_gradient_top)
		$nav_gradient_top = "#fff";
	if (! $nav_gradient_bottom)
		$nav_gradient_bottom = "#fff";
	if (! $nav_active_gradient_top)
		$nav_active_gradient_top = "#fff";
	if (! $nav_active_gradient_bottom)
		$nav_active_gradient_bottom = "#fff";
	if (! $nav_bd)
		$nav_bd = "#fff";
	if (! $nav_icon_colour)
		$nav_icon_colour = "#111";
	if (! $nav_active_icon_colour)
		$nav_active_icon_colour = "#000";
	if (! $banner_colour)
		$banner_colour = "#fff";
	if (! $link_colour)
		$link_colour = "#000";
	if (! $bgcolour)
		$bgcolour = "#fff";
	if (! $toolicon_colour)
		$toolicon_colour = "#111";
	if (! $toolicon_activecolour)
		$toolicon_activecolour = "#000";
	if (! $item_colour)
		$item_colour = "rgba(255,255,255,0.8)";
	if (! $comment_item_colour)
		$comment_item_colour = "rgba(255,255,255,0.4)";
	if (! $comment_border_colour)
		$comment_border_colour = "rgba(255,255,255,0.8)";
	if (! $font_colour)
		$font_colour = "#000";
	if (! $converse_width)
		$converse_width = "1024";
		
		

		
