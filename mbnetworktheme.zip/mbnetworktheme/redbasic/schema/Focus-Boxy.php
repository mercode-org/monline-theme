<?php

if (! $radiuspx)
	$radiuspx = "4";
if (! $comment_border_colour)
	$comment_border_colour = "rgb(238,238,238)";
