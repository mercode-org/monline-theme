<?php
	
	if (! $nav_bg)
		$nav_bg = "#f8f9fa";
	if (! $nav_icon_colour)
		$nav_icon_colour = "rgba(0, 0, 0, 0.5)";
	if (! $nav_active_icon_colour)
		$nav_active_icon_colour = "rgba(0, 0, 0, 0.7)";
	if (! $radius)
		$radius = "4px";
	if (! $banner_colour)
		$banner_colour = "rgba(0, 0, 0, 0.7)";

