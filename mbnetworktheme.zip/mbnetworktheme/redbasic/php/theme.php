<?php

/**
 *   * Name: Redbasic
 *   * Description: Hubzilla standard theme
 *   * Version: 2.1
 *   * MinVersion: 2.3.1
 *   * MaxVersion: 6.0
 *   * Author: Fabrixxm
 *   * Maintainer: Mike Macgirvin
 *   * Maintainer: Mario Vavti
 */

function redbasic_init(&$a) {

}
